<?php 

   session_start();
   include "db_conn.php";
   if (isset($_SESSION['username']) && isset($_SESSION['id'])) {   ?>

<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
	<form action="connect.php" method="POST">
					<div class="container mt-5">
						<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">Add New_Student</button>
						<div class="modal" id="myModal">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title">Add New_Student</h5>
										<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
									</div>
									<div class="modal-body">
										<!-- <form action="insert1.php" method="POST"> -->
											<div class="mb-3">
												<label class="form-label required">Id</label>
												<input  class="form-control" name="Id" required>
											</div>
											<div class="mb-3">
											<label class="form-label required">username</label>
											<input class="form-control" name="username" required>
											</div>
											<div class="mb-3">
												<label class="form-label required">password</label>
												<input type="password" class="form-control" name="password" required>
											</div>
											<div class="mb-3">
											<label class="form-label required">name</label>
											<input type="text" class="form-control" name="name" required>
											</div>
											<div class="mb-3">
											<label class="form-label required">Select User Type:</label>
												<select class="form-select mb-3" name="type" 
													aria-label="Default select example">
													<option value="guest" name="type">Admin</option>
													<option value="teacher" name="type">teacher</option>
													<option value="student" name="type">student</option>												
												</select>
											</div>
										<!-- </form> -->
									</div>
									<div class="modal-footer">
										<input type="submit" name="submit" class="btnRegister btn btn-primary" value="save">
									</div>
								</div>
							</div>
						</div>
					</div>
					<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
				</form>
</html>
<?php }else{
	header("Location: index.php");
} ?>