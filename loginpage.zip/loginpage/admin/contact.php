<?php include 'settings.php'; //include settings ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TEACHER</title>
    <style>
      .navigation-bar ul {
        padding: 0px;
        margin: 0px;
        text-align: center;
        display:inline-block;
        vertical-align:top;
        margin-top: 35px;
      }
      li {
        display: inline;
      }
      ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
      }
      .button {
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        padding: 15px 32px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
      }
      .button2 {background-color: #008CBA;} /* Blue */
    </style>
  </head>
  <body>
    <!-- <h2>This is Teacher's page</h2> -->
    <!-- <h2>Hello: <?php $ufunc->UserName(); //Show name who is in session user?></h2> -->
    <div class="navigation-bar">
    <img id="logo" src="walchandlogo.jpg" alt="logo" style="width:150px;height:100px;margin-right:200px;margin-top:20px;"> 
      <ul>
        <li><a href="index.php"><button class="button button2">Home</button></a></li>
        <li><a href="contact.php"><button class="button button2">Add Student</button></a></li>
        <li><a href="view.php"><button class="button button2">Check Database</button></a></li>
        <li><a href="about.asp"><button class="button button2">Actions</button></a></li>
        <li><a href="../../php_multi-user_login-master/includes/logout.php"><button class="button button2">Logout</button></a></li>
      </ul>
    </div>
    <hr>
    <!-- <div>
      <h2 style="text-align: center;">Student Database</h2>
    </div> -->
  </body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" a href="css/bootstrap.css"/>
    <title>Registration Form</title>
</head>
<body class="bg-white">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 m-auto">
                    <div class="card mt-5">
                        <div class="card-title">
                            <h3 class="bg-success text-white text-center py-3"> Registration Form in PHP</h3>
                        </div>
                        <div class="card-body">

                            <form action="insert.php" method="post">
                                <input type="int" class="form-control mb-2" placeholder=" User ID " name="id">
                                <input type="text" class="form-control mb-2" placeholder=" User Name " name="name">
                                <input type="email" class="form-control mb-2" placeholder=" User Email " name="email">
                                <input type="text" class="form-control mb-2" placeholder=" User Mobile " name="mobile">
                                <button class="btn btn-primary" name="submit">Submit</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    
</body>
</html>