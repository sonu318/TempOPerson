<?php
include '../../php_multi-user_login-master/includes/functions.php'; //include functions
include '../../php_multi-user_login-master/includes/connect.php'; //include connection
$ufunc = new UserFunctions;
$chss = new Login;
$chss->SessionCheck();
//Check user role is true
if (!isset($_SESSION['login']) || $_SESSION['role'] != "1") {
  header("Location:../../php_multi-user_login-master/includes/logout.php");
}
?>
