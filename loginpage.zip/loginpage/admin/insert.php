<?php

    require_once("connection.php");

    if(isset($_POST['submit']))
    {
        if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['mobile']) || empty($_POST['id']))
        {
            echo ' Please Fill in the Blanks ';
        }
        else
        {
            $UserID = $_POST['id'];
            $UserName = $_POST['name'];
            $UserEmail = $_POST['email'];
            $UserMobile = $_POST['mobile'];

            $query = " insert into records (User_ID, User_Name, User_Email,User_Mobile) values('$UserID','$UserName','$UserEmail','$UserMobile')";
            $result = mysqli_query($con,$query);

            if($result)
            {
                header("location:view.php");
            }
            else
            {
                echo '  Please Check Your Query ';
            }
        }
    }
    else
    {
        header("location:contact.php");
    }



?>