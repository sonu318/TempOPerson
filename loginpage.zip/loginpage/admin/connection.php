<?php 
$con=mysqli_connect("localhost","root","","crud"); 
if(!$con) { die(" Connection Error "); } 
?>