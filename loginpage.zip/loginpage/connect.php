<?php
	$Id = $_POST['Id'];
	$uname = $_POST['username'];
	$pass = $_POST['password'];
	$name = $_POST['name'];
	$type = $_POST['type'];
	$pass = md5($pass);
	
	//Database connection
	
	$conn = new mysqli('localhost','root','','phpmultiuserlogin');
	if($conn->connect_error){
		die('connection Failed :'.$conn->connect_error);
	}else{
		$query = " insert into new_users(id,role,username,password,name) values('$Id','$type','$uname','$pass','$name')";
		mysqli_query($conn,$query);
		//echo"Report saved successfully...";
		echo'<script>
            alert("Data inserted Sussessfully")
        </script>';
	}
	
?>